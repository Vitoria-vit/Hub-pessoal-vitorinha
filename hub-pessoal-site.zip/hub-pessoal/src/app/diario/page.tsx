
'use client'; // Add this directive for client-side interactivity

import React, { useState, useEffect } from 'react';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { Heart, Zap, MessageSquare, BookUser } from 'lucide-react';

const DiarioPage = () => {
  // State for mood, energy, journal entry, and letter
  const [mood, setMood] = useState<string | null>(null);
  const [energy, setEnergy] = useState<string | null>(null);
  const [journalEntry, setJournalEntry] = useState<string>('');
  const [letterToSelf, setLetterToSelf] = useState<string>('');

  // --- Local Storage Persistence (Basic Example) ---
  // Load saved data on component mount
  useEffect(() => {
    const savedMood = localStorage.getItem('diario_mood');
    const savedEnergy = localStorage.getItem('diario_energy');
    const savedLetter = localStorage.getItem('diario_letterToSelf');
    if (savedMood) setMood(savedMood);
    if (savedEnergy) setEnergy(savedEnergy);
    if (savedLetter) setLetterToSelf(savedLetter);
    // Journal entries are typically saved per entry, not loaded like this
  }, []);

  // Save letter to local storage when it changes
  const handleSaveLetter = () => {
    localStorage.setItem('diario_letterToSelf', letterToSelf);
    alert('Carta salva com sucesso!'); // Simple feedback
  };

  // Save mood/energy to local storage
  const handleSetMood = (newMood: string) => {
    setMood(newMood);
    localStorage.setItem('diario_mood', newMood);
  };

  const handleSetEnergy = (newEnergy: string) => {
    setEnergy(newEnergy);
    localStorage.setItem('diario_energy', newEnergy);
  };

  // Handle saving journal entry (basic alert for now)
  const handleSaveEntry = () => {
    // In a real app, you'd save this entry with a timestamp, maybe to local storage array or a backend
    console.log('Saving entry:', journalEntry);
    alert('Entrada do diário salva (ver console)!');
    setJournalEntry(''); // Clear textarea after saving
  };
  // --- End Local Storage --- 

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6 text-purple-700">Diário de Emoções e Autoconhecimento</h1>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Desabafo */}
        <Card className="md:col-span-2 bg-green-50">
          <h2 className="text-xl font-semibold mb-4 text-green-700 flex items-center">
            <MessageSquare className="mr-2" size={24} /> Espaço para Desabafos
          </h2>
          <textarea
            className="w-full h-40 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-300 focus:border-transparent resize-none bg-white"
            placeholder="Como você está se sentindo hoje? O que está passando pela sua mente?"
            value={journalEntry}
            onChange={(e) => setJournalEntry(e.target.value)}
          ></textarea>
          <Button variant="primary" className="mt-3 bg-green-600 hover:bg-green-700" onClick={handleSaveEntry}>Salvar Entrada</Button>
        </Card>

        {/* Rastreador de Humor e Energia */}
        <Card className="bg-orange-50">
          <h2 className="text-xl font-semibold mb-4 text-orange-700 flex items-center">
            <Heart className="mr-2" size={24} /> Rastreador de Humor
          </h2>
          <p className="text-sm text-gray-600 mb-3">Como você classificaria seu humor hoje?</p>
          <div className="flex flex-wrap gap-2 justify-center">
            {[
              { label: 'Feliz', emoji: '😊' },
              { label: 'Ok', emoji: '😐' },
              { label: 'Triste', emoji: '😢' },
              { label: 'Ansiosa', emoji: '😟' },
              { label: 'Irritada', emoji: '😠' }
            ].map(m => (
              <Button
                key={m.label}
                variant={mood === m.label ? 'primary' : 'secondary'}
                className={`text-xs sm:text-sm ${mood === m.label ? 'bg-orange-500 scale-105 shadow-md' : 'bg-orange-200 hover:bg-orange-300 text-orange-800'}`}
                onClick={() => handleSetMood(m.label)}
              >
                {m.emoji} {m.label}
              </Button>
            ))}
          </div>
          <h2 className="text-xl font-semibold mb-4 mt-6 text-orange-700 flex items-center">
            <Zap className="mr-2" size={24} /> Nível de Energia
          </h2>
          <p className="text-sm text-gray-600 mb-3">Como está sua energia hoje?</p>
          <div className="flex flex-wrap gap-2 justify-center">
            {[
              { label: 'Alta', emoji: '⚡' },
              { label: 'Média', emoji: '🔋' },
              { label: 'Baixa', emoji: '🔌' }
            ].map(e => (
              <Button
                key={e.label}
                variant={energy === e.label ? 'primary' : 'secondary'}
                className={`text-xs sm:text-sm ${energy === e.label ? 'bg-orange-500 scale-105 shadow-md' : 'bg-orange-200 hover:bg-orange-300 text-orange-800'}`}
                onClick={() => handleSetEnergy(e.label)}
              >
                 {e.emoji} {e.label}
              </Button>
            ))}
          </div>
        </Card>

        {/* Perguntas Reflexivas */}
        <Card className="bg-teal-50">
          <h2 className="text-xl font-semibold mb-4 text-teal-700">Perguntas Reflexivas</h2>
          <ul className="list-disc list-inside space-y-2 text-gray-700 text-sm md:text-base">
            <li>O que estou sentindo predominante hoje?</li>
            <li>Há algo que estou evitando pensar ou sentir?</li>
            <li>Do que meu corpo e minha mente precisam agora?</li>
            <li>Qual pequena ação de autocuidado posso fazer por mim hoje?</li>
            <li>Pelo que sou grata neste momento?</li>
          </ul>
        </Card>

        {/* Carta para mim mesma */}
        <Card className="md:col-span-2 bg-pink-50">
          <h2 className="text-xl font-semibold mb-4 text-pink-700 flex items-center">
            <BookUser className="mr-2" size={24} /> Carta Para Mim Mesma
          </h2>
          <textarea
            className="w-full h-48 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-pink-300 focus:border-transparent resize-none bg-white"
            placeholder="Escreva uma carta gentil e encorajadora para você mesma. Atualize sempre que sentir necessidade..."
            value={letterToSelf}
            onChange={(e) => setLetterToSelf(e.target.value)}
          ></textarea>
           <Button variant="primary" className="mt-3" onClick={handleSaveLetter}>Salvar Carta</Button>
        </Card>

      </div>
    </div>
  );
};

export default DiarioPage;

