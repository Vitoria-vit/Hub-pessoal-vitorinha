import React from 'react';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { AlertTriangle, HeartHandshake, CheckSquare, BedDouble, ShowerHead, Utensils, Anchor, Sparkles } from 'lucide-react';

const ChecklistItem = ({ icon, text }: { icon: React.ReactNode, text: string }) => (
  <li className="flex items-center mb-2 text-gray-700">
    <span className="mr-3 text-red-500">{icon}</span>
    <span>{text}</span>
  </li>
);

const RecomecoPage = () => {
  return (
    <div>
      <div className="text-center mb-8">
        <Button variant="primary" className="bg-red-600 hover:bg-red-700 text-lg px-8 py-4">
          <AlertTriangle className="inline-block mr-2" size={24} />
          Socorro, estou me perdendo
        </Button>
      </div>

      <Card className="bg-red-50 border border-red-200">
        <h1 className="text-2xl font-bold mb-4 text-red-700 text-center">Plano de Emergência para Recaídas</h1>
        
        <p className="text-center text-gray-600 mb-6 italic">
          Respire fundo. Você não está sozinha. Um passo de cada vez.
        </p>

        <div className="grid md:grid-cols-3 gap-6 mb-6">
          {/* Checklist Emocional */}
          <div className="bg-white p-4 rounded shadow-sm border border-red-100">
            <h2 className="text-lg font-semibold mb-3 text-red-600 flex items-center">
              <HeartHandshake className="mr-2" size={20} /> Checklist Emocional
            </h2>
            <ul>
              <ChecklistItem icon={<CheckSquare size={18} />} text="Respirar fundo 3x" />
              <ChecklistItem icon={<CheckSquare size={18} />} text="Beber um copo d'água" />
              <ChecklistItem icon={<CheckSquare size={18} />} text="Validar o que estou sentindo" />
              <ChecklistItem icon={<CheckSquare size={18} />} text="Lembrar que isso vai passar" />
              <ChecklistItem icon={<CheckSquare size={18} />} text="Pedir ajuda se precisar" />
            </ul>
          </div>

          {/* Ações Mínimas do Dia */}
          <div className="bg-white p-4 rounded shadow-sm border border-red-100">
            <h2 className="text-lg font-semibold mb-3 text-red-600 flex items-center">
              <Anchor className="mr-2" size={20} /> Ações Mínimas do Dia
            </h2>
            <ul>
              <ChecklistItem icon={<BedDouble size={18} />} text="Levantar e arrumar a cama" />
              <ChecklistItem icon={<ShowerHead size={18} />} text="Tomar um banho" />
              <ChecklistItem icon={<Utensils size={18} />} text="Comer algo (qualquer coisa)" />
              <ChecklistItem icon={<CheckSquare size={18} />} text="Abrir a janela / Ver a luz do sol" />
              <ChecklistItem icon={<CheckSquare size={18} />} text="Fazer UMA coisa da rotina" />
            </ul>
          </div>

          {/* Lembretes de Força */}
          <div className="bg-white p-4 rounded shadow-sm border border-red-100">
            <h2 className="text-lg font-semibold mb-3 text-red-600 flex items-center">
              <Sparkles className="mr-2" size={20} /> Lembretes de Força
            </h2>
            <ul className="list-disc list-inside space-y-2 text-sm text-gray-700">
              <li>Você já superou dias difíceis antes.</li>
              <li>Seja gentil e paciente consigo mesma.</li>
              <li>O progresso não é linear, recaídas fazem parte.</li>
              <li>Sua sensibilidade também é sua força.</li>
              <li>Peça ajuda, você não precisa passar por isso só.</li>
              <li>Amanhã é um novo dia.</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-red-200 text-center">
          <p className="text-xl font-semibold text-red-800">
            "Se você tá aqui, é porque não desistiu."
          </p>
        </div>
      </Card>
    </div>
  );
};

export default RecomecoPage;

