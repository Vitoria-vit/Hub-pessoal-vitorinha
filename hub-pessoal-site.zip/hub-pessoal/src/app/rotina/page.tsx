'use client'; // Add this directive for client-side interactivity

import React, { useState } from 'react';
import Card from '@/components/Card';
import { CheckSquare, Coffee, Sun, Moon, Droplet, BookOpen, Dumbbell, Utensils, ShowerHead, BedDouble, Sparkles, Anchor, HeartHandshake, AlertTriangle } from 'lucide-react';

const HabitItem = ({ icon, text }: { icon: React.ReactNode, text: string }) => {
  const [isChecked, setIsChecked] = useState(false);

  return (
    <li className="flex items-center mb-2 text-gray-700">
      <span className="mr-3 text-pink-500">{icon}</span>
      <span className={`flex-grow ${isChecked ? 'line-through text-gray-400' : ''}`}>{text}</span>
      <CheckSquare
        className={`ml-auto cursor-pointer ${isChecked ? 'text-green-500' : 'text-gray-300 hover:text-green-400'}`}
        size={20}
        onClick={() => setIsChecked(!isChecked)}
      />
    </li>
  );
};

const RotinaPage = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6 text-purple-700">Minha Rotina Ideal</h1>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Manhã */}
        <Card className="bg-yellow-50">
          <h2 className="text-xl font-semibold mb-4 text-yellow-700 flex items-center"><Sun className="mr-2" size={24} /> Manhã</h2>
          <h3 className="font-semibold mb-2 text-yellow-600">Ritual Matinal:</h3>
          <textarea
            className="w-full text-sm text-gray-600 mb-4 p-2 border border-yellow-200 rounded bg-white resize-none focus:ring-1 focus:ring-yellow-400"
            placeholder="Descreva seu ritual matinal aqui..."
            rows={3}
          ></textarea>
          <h3 className="font-semibold mb-2 text-yellow-600">Checklist:</h3>
          <ul>
            <HabitItem icon={<BedDouble size={18} />} text="Arrumar a cama" />
            <HabitItem icon={<Droplet size={18} />} text="Beber água" />
            <HabitItem icon={<Coffee size={18} />} text="Café da manhã nutritivo" />
            <HabitItem icon={<Dumbbell size={18} />} text="Exercício / Movimento" />
            <HabitItem icon={<BookOpen size={18} />} text="Leitura / Estudo" />
          </ul>
        </Card>

        {/* Tarde */}
        <Card className="bg-blue-50">
          <h2 className="text-xl font-semibold mb-4 text-blue-700 flex items-center"><Sun className="mr-2" size={24} /> Tarde</h2> {/* Using Sun icon as placeholder */}
          <h3 className="font-semibold mb-2 text-blue-600">Checklist:</h3>
          <ul>
            <HabitItem icon={<BookOpen size={18} />} text="Trabalho / Estudo focado" />
            <HabitItem icon={<Droplet size={18} />} text="Hidratação" />
            <HabitItem icon={<Coffee size={18} />} text="Pausa consciente" />
            <HabitItem icon={<Utensils size={18} />} text="Almoço" />
            {/* Add more afternoon habits */}
          </ul>
        </Card>

        {/* Noite */}
        <Card className="bg-indigo-50">
          <h2 className="text-xl font-semibold mb-4 text-indigo-700 flex items-center"><Moon className="mr-2" size={24} /> Noite</h2>
          <h3 className="font-semibold mb-2 text-indigo-600">Ritual Noturno:</h3>
           <textarea
            className="w-full text-sm text-gray-600 mb-4 p-2 border border-indigo-200 rounded bg-white resize-none focus:ring-1 focus:ring-indigo-400"
            placeholder="Descreva seu ritual noturno aqui..."
            rows={3}
          ></textarea>
          <h3 className="font-semibold mb-2 text-indigo-600">Checklist:</h3>
          <ul>
            <HabitItem icon={<Utensils size={18} />} text="Jantar leve" />
            <HabitItem icon={<ShowerHead size={18} />} text="Skincare" />
            <HabitItem icon={<BookOpen size={18} />} text="Desconectar telas" />
            <HabitItem icon={<Sparkles size={18} />} text="Relaxamento / Meditação" />
            <HabitItem icon={<BedDouble size={18} />} text="Dormir cedo" />
          </ul>
        </Card>
      </div>
    </div>
  );
};

export default RotinaPage;

