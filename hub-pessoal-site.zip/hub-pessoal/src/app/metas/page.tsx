"'use client"); // Add this directive for client-side interactivity

import React, { useState, useEffect } from 'react';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { Target, Award, TrendingUp, HeartHandshake, CalendarCheck, Star, Trash2, Edit } from 'lucide-react';

interface Goal {
  id: string;
  text: string;
  type: 'pessoal' | 'emocional';
  progress: number;
  term: 'curto' | 'medio' | 'longo';
}

// Placeholder component for a single goal item
const GoalItem = ({ goal, onUpdateProgress, onMarkComplete, onDelete }: {
  goal: Goal;
  onUpdateProgress: (id: string, progress: number) => void;
  onMarkComplete: (id: string) => void;
  onDelete: (id: string) => void;
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [currentProgress, setCurrentProgress] = useState(goal.progress);

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newProgress = parseInt(e.target.value, 10);
    setCurrentProgress(newProgress);
  };

  const handleSaveProgress = () => {
    onUpdateProgress(goal.id, currentProgress);
    setIsEditing(false);
  };

  return (
    <li className="mb-3 p-3 border rounded-md flex items-center bg-white shadow-sm transition-shadow hover:shadow-md">
      {goal.type === 'pessoal' ? <CalendarCheck size={18} className="mr-3 text-blue-500 flex-shrink-0" /> : <HeartHandshake size={18} className="mr-3 text-pink-500 flex-shrink-0" />}
      <span className={`flex-grow text-gray-700 mr-3 ${goal.progress === 100 ? 'line-through text-gray-400' : ''}`}>{goal.text}</span>

      {/* Progress Bar & Input */}
      {isEditing ? (
        <div className="flex items-center mx-2">
          <input
            type="range"
            min="0"
            max="100"
            value={currentProgress}
            onChange={handleProgressChange}
            className="w-20 h-2 bg-gray-200 rounded-full appearance-none cursor-pointer mr-2"
            style={{ background: `linear-gradient(to right, #4ade80 ${currentProgress}%, #e5e7eb ${currentProgress}%)` }}
          />
          <span className="text-xs text-gray-600 w-8 text-right">{currentProgress}%</span>
          <Button size="sm" variant="secondary" onClick={handleSaveProgress} className="ml-2 text-xs px-1 py-0.5">Salvar</Button>
        </div>
      ) : (
        <div className="flex items-center mx-2 cursor-pointer" onClick={() => setIsEditing(true)} title="Clique para editar progresso">
          <div className="w-20 h-2 bg-gray-200 rounded-full mr-2">
            <div className="h-2 bg-green-500 rounded-full" style={{ width: `${goal.progress}%` }}></div>
          </div>
          <span className="text-xs text-gray-500 w-8 text-right">{goal.progress}%</span>
          <Edit size={12} className="ml-1 text-gray-400 hover:text-gray-600" />
        </div>
      )}

      {/* Action Buttons */}
      <Award
        size={18}
        className={`ml-2 cursor-pointer ${goal.progress === 100 ? 'text-yellow-500' : 'text-gray-300 hover:text-yellow-500'}`}
        title="Marcar como Concluída (100%)"
        onClick={() => onMarkComplete(goal.id)}
      />
       <Trash2
        size={16}
        className="ml-2 text-gray-300 hover:text-red-500 cursor-pointer"
        title="Excluir Meta"
        onClick={() => onDelete(goal.id)}
      />
    </li>
  );
};

const MetasPage = () => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [newGoalText, setNewGoalText] = useState('');
  const [newGoalType, setNewGoalType] = useState<'pessoal' | 'emocional'>('pessoal');
  const [newGoalTerm, setNewGoalTerm] = useState<'curto' | 'medio' | 'longo'>('curto');

  // --- Local Storage Persistence ---
  useEffect(() => {
    const savedGoals = localStorage.getItem('metas_goals');
    if (savedGoals) {
      setGoals(JSON.parse(savedGoals));
    } else {
      // Initialize with example goals if none are saved
      setGoals([
        { id: 'g1', text: 'Acordar às 6h todos os dias úteis', type: 'pessoal', progress: 75, term: 'curto' },
        { id: 'g2', text: 'Organizar planilha financeira', type: 'pessoal', progress: 30, term: 'curto' },
        { id: 'g3', text: 'Praticar pausa consciente 1x/dia', type: 'emocional', progress: 90, term: 'curto' },
        { id: 'g4', text: 'Planejar viagem de férias', type: 'pessoal', progress: 10, term: 'medio' },
        { id: 'g5', text: 'Identificar 1 gatilho de autossabotagem', type: 'emocional', progress: 40, term: 'medio' },
        { id: 'g6', text: 'Guardar X para reserva de emergência', type: 'pessoal', progress: 5, term: 'longo' },
      ]);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('metas_goals', JSON.stringify(goals));
  }, [goals]);

  const updateGoalProgress = (id: string, progress: number) => {
    setGoals(goals.map(g => g.id === id ? { ...g, progress: Math.max(0, Math.min(100, progress)) } : g));
  };

  const markGoalComplete = (id: string) => {
    setGoals(goals.map(g => g.id === id ? { ...g, progress: 100 } : g));
  };

  const deleteGoal = (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta meta?')) {
        setGoals(goals.filter(g => g.id !== id));
    }
  };

  const addGoal = () => {
    if (!newGoalText.trim()) return;
    const newGoal: Goal = {
      id: Date.now().toString(), // Simple unique ID
      text: newGoalText,
      type: newGoalType,
      progress: 0,
      term: newGoalTerm,
    };
    setGoals([...goals, newGoal]);
    setNewGoalText(''); // Clear input
  };
  // --- End Local Storage ---

  const filterGoalsByTerm = (term: 'curto' | 'medio' | 'longo') => goals.filter(g => g.term === term);

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6 text-purple-700">Sistema de Metas e Progresso</h1>

      {/* Add New Goal Form */}
      <Card className="mb-6 bg-gray-50">
        <h2 className="text-xl font-semibold mb-4 text-gray-700">Adicionar Nova Meta</h2>
        <div className="flex flex-wrap gap-4 items-end">
          <input
            type="text"
            value={newGoalText}
            onChange={(e) => setNewGoalText(e.target.value)}
            placeholder="Descrição da meta..."
            className="flex-grow p-2 border rounded bg-white focus:ring-1 focus:ring-purple-400"
          />
          <select value={newGoalType} onChange={(e) => setNewGoalType(e.target.value as any)} className="p-2 border rounded bg-white">
            <option value="pessoal">Pessoal</option>
            <option value="emocional">Emocional</option>
          </select>
          <select value={newGoalTerm} onChange={(e) => setNewGoalTerm(e.target.value as any)} className="p-2 border rounded bg-white">
            <option value="curto">Curto Prazo</option>
            <option value="medio">Médio Prazo</option>
            <option value="longo">Longo Prazo</option>
          </select>
          <Button onClick={addGoal}>Adicionar</Button>
        </div>
      </Card>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Curto Prazo */}
        <Card className="bg-lime-50">
          <h2 className="text-xl font-semibold mb-4 text-lime-700 flex items-center">
            <Target className="mr-2" size={24} /> Curto Prazo
          </h2>
          <ul>
            {filterGoalsByTerm('curto').map(goal => (
              <GoalItem key={goal.id} goal={goal} onUpdateProgress={updateGoalProgress} onMarkComplete={markGoalComplete} onDelete={deleteGoal} />
            ))}
             {filterGoalsByTerm('curto').length === 0 && <p className="text-sm text-gray-500 italic">Nenhuma meta de curto prazo adicionada.</p>}
          </ul>
        </Card>

        {/* Médio Prazo */}
        <Card className="bg-cyan-50">
          <h2 className="text-xl font-semibold mb-4 text-cyan-700 flex items-center">
            <TrendingUp className="mr-2" size={24} /> Médio Prazo
          </h2>
          <ul>
            {filterGoalsByTerm('medio').map(goal => (
              <GoalItem key={goal.id} goal={goal} onUpdateProgress={updateGoalProgress} onMarkComplete={markGoalComplete} onDelete={deleteGoal} />
            ))}
            {filterGoalsByTerm('medio').length === 0 && <p className="text-sm text-gray-500 italic">Nenhuma meta de médio prazo adicionada.</p>}
          </ul>
        </Card>

        {/* Longo Prazo */}
        <Card className="bg-amber-50">
          <h2 className="text-xl font-semibold mb-4 text-amber-700 flex items-center">
            <Star className="mr-2" size={24} /> Longo Prazo
          </h2>
          <ul>
            {filterGoalsByTerm('longo').map(goal => (
              <GoalItem key={goal.id} goal={goal} onUpdateProgress={updateGoalProgress} onMarkComplete={markGoalComplete} onDelete={deleteGoal} />
            ))}
            {filterGoalsByTerm('longo').length === 0 && <p className="text-sm text-gray-500 italic">Nenhuma meta de longo prazo adicionada.</p>}
          </ul>
        </Card>
      </div>

      {/* Prêmios Simbólicos */}
      <Card className="mt-8 bg-yellow-100">
        <h2 className="text-xl font-semibold mb-4 text-yellow-800 flex items-center">
          <Award className="mr-2" size={24} /> Quadro de Prêmios Simbólicos
        </h2>
        <p className="text-gray-700 mb-3">Celebre suas conquistas! Defina pequenas recompensas para se motivar.</p>
        {/* This section remains static as per the original request */}
        <ul className="list-disc list-inside space-y-1 text-yellow-900 text-sm">
          <li>Meta de curto prazo concluída: Um café especial ou um banho relaxante.</li>
          <li>Meta de médio prazo alcançada: Comprar um livro desejado ou um dia de folga.</li>
          <li>Marco importante atingido: Uma pequena viagem ou um presente significativo.</li>
          <li><span className="italic">(Adicione suas próprias ideias aqui!)</span></li>
        </ul>
      </Card>
    </div>
  );
};

export default MetasPage;

