"'use client"); // Add this directive for client-side interactivity

import React, { useState, useEffect } from 'react';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { DollarSign, PiggyBank, CalendarDays, BarChart3, Clock, Zap, Eye, Edit, Save } from 'lucide-react';

interface FinancialData {
  monthlyIncome: { label: string; value: number }[];
  monthlyExpenses: { label: string; value: number }[];
  savingsGoals: { label: string; target: number; current: number }[];
  fixedExpenses: { label: string; value: number }[];
  variableExpenses: { label: string; value: number }[];
}

// Editable Finance Item Component
const EditableFinanceItem = ({ item, onSave, category }: {
  item: { label: string; value: number };
  onSave: (category: string, oldLabel: string, newLabel: string, newValue: number) => void;
  category: string;
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [currentLabel, setCurrentLabel] = useState(item.label);
  const [currentValue, setCurrentValue] = useState(item.value.toString());

  const handleSave = () => {
    const newValue = parseFloat(currentValue) || 0;
    onSave(category, item.label, currentLabel, newValue);
    setIsEditing(false);
  };

  return (
    <li className="flex justify-between items-center mb-2 p-2 bg-white rounded shadow-sm">
      {isEditing ? (
        <>
          <input
            type="text"
            value={currentLabel}
            onChange={(e) => setCurrentLabel(e.target.value)}
            className="text-sm p-1 border rounded mr-2 flex-grow"
            placeholder="Descrição"
          />
          <input
            type="number"
            value={currentValue}
            onChange={(e) => setCurrentValue(e.target.value)}
            className="font-semibold text-sm p-1 border rounded w-24"
            placeholder="Valor"
          />
          <Save size={16} className="ml-2 text-green-600 cursor-pointer" onClick={handleSave} />
        </>
      ) : (
        <>
          <span className="text-sm text-gray-700">{item.label}</span>
          <span className="font-semibold text-sm text-gray-700">R$ {item.value.toFixed(2)}</span>
          <Edit size={14} className="ml-2 text-gray-400 hover:text-blue-600 cursor-pointer" onClick={() => setIsEditing(true)} />
        </>
      )}
    </li>
  );
};

// Editable Savings Goal Component
const EditableSavingsGoal = ({ goal, onSave }: {
    goal: { label: string; target: number; current: number };
    onSave: (oldLabel: string, newLabel: string, newTarget: number, newCurrent: number) => void;
}) => {
    const [isEditing, setIsEditing] = useState(false);
    const [currentLabel, setCurrentLabel] = useState(goal.label);
    const [currentTarget, setCurrentTarget] = useState(goal.target.toString());
    const [currentAmount, setCurrentAmount] = useState(goal.current.toString());

    const handleSave = () => {
        const newTarget = parseFloat(currentTarget) || 0;
        const newCurrent = parseFloat(currentAmount) || 0;
        onSave(goal.label, currentLabel, newTarget, newCurrent);
        setIsEditing(false);
    };

    const progress = goal.target > 0 ? Math.min(100, (goal.current / goal.target) * 100) : 0;

    return (
        <li className="mb-3 p-3 border rounded-md bg-white shadow-sm">
            {isEditing ? (
                <div className="space-y-2">
                    <input type="text" value={currentLabel} onChange={(e) => setCurrentLabel(e.target.value)} className="text-sm p-1 border rounded w-full" placeholder="Nome da Meta" />
                    <div className="flex gap-2">
                        <input type="number" value={currentTarget} onChange={(e) => setCurrentTarget(e.target.value)} className="text-sm p-1 border rounded w-1/2" placeholder="Meta (R$)" />
                        <input type="number" value={currentAmount} onChange={(e) => setCurrentAmount(e.target.value)} className="text-sm p-1 border rounded w-1/2" placeholder="Atual (R$)" />
                    </div>
                    <Button size="sm" variant="secondary" onClick={handleSave} className="text-xs">Salvar</Button>
                </div>
            ) : (
                <div onClick={() => setIsEditing(true)} className="cursor-pointer">
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-blue-800">{goal.label}</span>
                        <Edit size={14} className="text-gray-400 hover:text-blue-600" />
                    </div>
                    <div className="text-xs text-gray-600 mb-1">
                        Meta: R$ {goal.target.toFixed(2)} / Atual: R$ {goal.current.toFixed(2)}
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full">
                        <div className="h-2 bg-blue-500 rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                    <div className="text-right text-xs text-blue-700 mt-1">{progress.toFixed(0)}%</div>
                </div>
            )}
        </li>
    );
};

const FinancasPage = () => {
  const [data, setData] = useState<FinancialData>({
    monthlyIncome: [],
    monthlyExpenses: [],
    savingsGoals: [],
    fixedExpenses: [],
    variableExpenses: [],
  });
  const [newItemLabel, setNewItemLabel] = useState('');
  const [newItemValue, setNewItemValue] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<'monthlyIncome' | 'monthlyExpenses' | 'fixedExpenses' | 'variableExpenses'>('monthlyIncome');

  // --- Local Storage Persistence ---
  useEffect(() => {
    const savedData = localStorage.getItem('financas_data');
    if (savedData) {
      setData(JSON.parse(savedData));
    } else {
      // Initialize with example data if none is saved
      setData({
        monthlyIncome: [{ label: 'Salário', value: 5000 }, { label: 'Freelance', value: 800 }],
        monthlyExpenses: [
          { label: 'Aluguel', value: 1500 }, { label: 'Contas (Água, Luz, Net)', value: 350 },
          { label: 'Mercado', value: 600 }, { label: 'Transporte', value: 150 },
          { label: 'Lazer', value: 400 }, { label: 'Cartão Crédito', value: 700 }
        ],
        savingsGoals: [
          { label: 'Reserva de Emergência', target: 10000, current: 3500 },
          { label: 'Viagem (Ex: Europa)', target: 15000, current: 1200 },
          { label: 'Lazer/Compras Grandes', target: 5000, current: 500 }
        ],
        fixedExpenses: [{ label: 'Aluguel', value: 1500 }, { label: 'Plano Saúde', value: 400 }, { label: 'Assinaturas', value: 100 }],
        variableExpenses: [{ label: 'Mercado', value: 600 }, { label: 'Lazer', value: 400 }, { label: 'Transporte', value: 150 }],
      });
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('financas_data', JSON.stringify(data));
  }, [data]);

  const handleSaveItem = (category: string, oldLabel: string, newLabel: string, newValue: number) => {
    setData(prevData => {
      const categoryKey = category as keyof FinancialData;
      // Ensure the category exists and is an array
      if (!Array.isArray(prevData[categoryKey])) return prevData;
      
      const updatedCategory = (prevData[categoryKey] as any[]).map(item =>
        item.label === oldLabel ? { ...item, label: newLabel, value: newValue } : item
      );
      return { ...prevData, [categoryKey]: updatedCategory };
    });
  };

  const handleSaveSavingsGoal = (oldLabel: string, newLabel: string, newTarget: number, newCurrent: number) => {
      setData(prevData => ({
          ...prevData,
          savingsGoals: prevData.savingsGoals.map(goal =>
              goal.label === oldLabel ? { ...goal, label: newLabel, target: newTarget, current: newCurrent } : goal
          )
      }));
  };

  const handleAddItem = () => {
      const value = parseFloat(newItemValue) || 0;
      if (!newItemLabel.trim() || value <= 0) return;

      const newItem = { label: newItemLabel, value };
      setData(prevData => ({
          ...prevData,
          [newItemCategory]: [...prevData[newItemCategory], newItem]
      }));
      setNewItemLabel('');
      setNewItemValue('');
  };

  // --- Calculations ---
  const totalIncome = data.monthlyIncome.reduce((sum, item) => sum + item.value, 0);
  const totalExpenses = data.monthlyExpenses.reduce((sum, item) => sum + item.value, 0);
  const monthlyBalance = totalIncome - totalExpenses;

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6 text-purple-700">Finanças e Planejamento de Vida</h1>

       {/* Add New Item Form */}
       <Card className="mb-6 bg-gray-50">
            <h2 className="text-xl font-semibold mb-4 text-gray-700">Adicionar Item Financeiro</h2>
            <div className="flex flex-wrap gap-4 items-end">
                <input
                    type="text"
                    value={newItemLabel}
                    onChange={(e) => setNewItemLabel(e.target.value)}
                    placeholder="Descrição..."
                    className="flex-grow p-2 border rounded bg-white focus:ring-1 focus:ring-purple-400"
                />
                 <input
                    type="number"
                    value={newItemValue}
                    onChange={(e) => setNewItemValue(e.target.value)}
                    placeholder="Valor (R$)"
                    className="p-2 border rounded bg-white w-32 focus:ring-1 focus:ring-purple-400"
                />
                <select value={newItemCategory} onChange={(e) => setNewItemCategory(e.target.value as any)} className="p-2 border rounded bg-white">
                    <option value="monthlyIncome">Entrada Mensal</option>
                    <option value="monthlyExpenses">Saída Mensal</option>
                    <option value="fixedExpenses">Despesa Fixa</option>
                    <option value="variableExpenses">Despesa Variável</option>
                    {/* Savings goals are handled separately */}
                </select>
                <Button onClick={handleAddItem}>Adicionar</Button>
            </div>
        </Card>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

        {/* Planejamento Mensal */}
        <Card className="bg-green-50 lg:col-span-2">
          <h2 className="text-xl font-semibold mb-4 text-green-700 flex items-center">
            <CalendarDays className="mr-2" size={24} /> Planejamento Mensal
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold mb-2 text-green-600">Entradas (+)</h3>
              <ul>
                {data.monthlyIncome.map(item => (
                  <EditableFinanceItem key={item.label} item={item} onSave={handleSaveItem} category="monthlyIncome" />
                ))}
                <li className="flex justify-between items-center mt-2 pt-2 border-t border-green-200">
                  <span className="font-bold text-green-800">Total Entradas:</span>
                  <span className="font-bold text-green-800">R$ {totalIncome.toFixed(2)}</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-red-600">Saídas (-)</h3>
              <ul>
                {data.monthlyExpenses.map(item => (
                  <EditableFinanceItem key={item.label} item={item} onSave={handleSaveItem} category="monthlyExpenses" />
                ))}
                <li className="flex justify-between items-center mt-2 pt-2 border-t border-red-200">
                  <span className="font-bold text-red-800">Total Saídas:</span>
                  <span className="font-bold text-red-800">R$ {totalExpenses.toFixed(2)}</span>
                </li>
              </ul>
            </div>
          </div>
          <div className={`mt-4 pt-3 border-t border-gray-300 text-center ${monthlyBalance >= 0 ? 'text-blue-800' : 'text-red-800'}`}>
            <h3 className="text-lg font-semibold">Saldo do Mês: R$ {monthlyBalance.toFixed(2)}</h3>
          </div>
        </Card>

        {/* Planejamento de Saving */}
        <Card className="bg-blue-50">
          <h2 className="text-xl font-semibold mb-4 text-blue-700 flex items-center">
            <PiggyBank className="mr-2" size={24} /> Planejamento de Saving
          </h2>
          <ul>
             {data.savingsGoals.map(goal => (
                 <EditableSavingsGoal key={goal.label} goal={goal} onSave={handleSaveSavingsGoal} />
             ))}
             {/* Add button for new savings goal could be added here */} 
          </ul>
        </Card>

        {/* Resumo Contas Fixas e Variáveis */}
        <Card className="bg-yellow-50">
          <h2 className="text-xl font-semibold mb-4 text-yellow-700 flex items-center">
            <BarChart3 className="mr-2" size={24} /> Resumo: Fixas vs. Variáveis
          </h2>
          <h3 className="font-semibold mb-2 text-yellow-600">Contas Fixas</h3>
          <ul>
             {data.fixedExpenses.map(item => (
                  <EditableFinanceItem key={item.label} item={item} onSave={handleSaveItem} category="fixedExpenses" />
             ))}
          </ul>
          <h3 className="font-semibold mt-4 mb-2 text-orange-600">Contas Variáveis</h3>
          <ul>
             {data.variableExpenses.map(item => (
                  <EditableFinanceItem key={item.label} item={item} onSave={handleSaveItem} category="variableExpenses" />
             ))}
          </ul>
        </Card>

        {/* Divisões Visuais (Conceitual - Static) */}
        <Card className="bg-purple-50 lg:col-span-2">
          <h2 className="text-xl font-semibold mb-4 text-purple-700">Gestão de Recursos Pessoais</h2>
          <p className="text-sm text-gray-600 mb-4">Lembre-se de equilibrar seus recursos além do dinheiro:</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-3 bg-green-100 rounded-lg shadow-sm">
              <DollarSign className="mx-auto mb-1 text-green-700" size={24} />
              <span className="text-sm font-medium text-green-800">Dinheiro</span>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg shadow-sm">
              <Clock className="mx-auto mb-1 text-blue-700" size={24} />
              <span className="text-sm font-medium text-blue-800">Tempo</span>
            </div>
            <div className="p-3 bg-yellow-100 rounded-lg shadow-sm">
              <Zap className="mx-auto mb-1 text-yellow-700" size={24} />
              <span className="text-sm font-medium text-yellow-800">Energia</span>
            </div>
            <div className="p-3 bg-pink-100 rounded-lg shadow-sm">
              <Eye className="mx-auto mb-1 text-pink-700" size={24} />
              <span className="text-sm font-medium text-pink-800">Atenção</span>
            </div>
          </div>
        </Card>

      </div>
    </div>
  );
};

export default FinancasPage;

