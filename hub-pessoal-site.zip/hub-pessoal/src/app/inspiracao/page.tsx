"use client"; // Add this directive for client-side interactivity

import React, { useState, useEffect } from 'react';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { Image as ImageIcon, Quote, Music, Sparkles, Heart, Plus, Trash2, Edit, Save } from 'lucide-react';

interface InspirationData {
  quotes: string[];
  music: string[];
  whys: { question: string; answer: string }[];
  altarContent: string;
  // Image URLs could be added here if needed: images: string[];
}

// Editable Item Component (for quotes, music)
const EditableListItem = ({ item, onSave, onDelete, placeholder }: {
  item: string;
  onSave: (oldItem: string, newItem: string) => void;
  onDelete: (item: string) => void;
  placeholder: string;
}) => {
  const [isEditing, setIsEditing] = useState(item === ''); // Start editing if it's a new item
  const [currentItem, setCurrentItem] = useState(item);

  const handleSave = () => {
    if (currentItem.trim()) {
      onSave(item, currentItem);
      setIsEditing(false);
    } else {
      // If saved while empty, treat as delete if it wasn't a new item
      if (item !== '') {
        onDelete(item);
      }
      setIsEditing(false); // Exit editing mode regardless
    }
  };

  const handleDelete = () => {
    onDelete(item);
  };

  return (
    <li className="flex items-center mb-2 text-gray-700 text-sm">
      {isEditing ? (
        <>
          <input
            type="text"
            value={currentItem}
            onChange={(e) => setCurrentItem(e.target.value)}
            placeholder={placeholder}
            className="flex-grow p-1 border rounded mr-2 bg-white"
            autoFocus
          />
          <Save size={16} className="text-green-600 cursor-pointer mr-2" onClick={handleSave} />
          {item !== '' && <Trash2 size={16} className="text-red-500 cursor-pointer" onClick={handleDelete} />}
        </>
      ) : (
        <>
          <span className="flex-grow mr-2">{item}</span>
          <Edit size={14} className="text-gray-400 hover:text-blue-600 cursor-pointer mr-2" onClick={() => setIsEditing(true)} />
          <Trash2 size={14} className="text-gray-400 hover:text-red-500 cursor-pointer" onClick={handleDelete} />
        </>
      )}
    </li>
  );
};

// Editable Why Component
const EditableWhyItem = ({ why, onSave }: {
  why: { question: string; answer: string };
  onSave: (question: string, newAnswer: string) => void;
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [currentAnswer, setCurrentAnswer] = useState(why.answer);

  const handleSave = () => {
    onSave(why.question, currentAnswer);
    setIsEditing(false);
  };

  return (
    <div className="mb-3">
      <strong className="text-gray-800 text-sm">{why.question}</strong>
      {isEditing ? (
        <div className="flex items-center mt-1">
          <textarea
            value={currentAnswer}
            onChange={(e) => setCurrentAnswer(e.target.value)}
            placeholder="Sua resposta..."
            className="flex-grow p-1 border rounded mr-2 text-sm bg-white resize-none"
            rows={2}
          />
          <Save size={16} className="text-green-600 cursor-pointer" onClick={handleSave} />
        </div>
      ) : (
        <div className="flex items-start mt-1">
          <p className="text-gray-600 italic text-sm flex-grow mr-2">{why.answer || '(Clique para adicionar sua resposta)'}</p>
          <Edit size={14} className="text-gray-400 hover:text-blue-600 cursor-pointer flex-shrink-0" onClick={() => setIsEditing(true)} />
        </div>
      )}
    </div>
  );
};

const InspiracaoPage = () => {
  const [data, setData] = useState<InspirationData>({
    quotes: [],
    music: [],
    whys: [],
    altarContent: '',
  });
  const [newItemType, setNewItemType] = useState<'quotes' | 'music' | null>(null);

  // --- Local Storage Persistence ---
  useEffect(() => {
    const savedData = localStorage.getItem('inspiracao_data');
    if (savedData) {
      setData(JSON.parse(savedData));
    } else {
      // Initialize with example data if none is saved
      setData({
        quotes: ['"A força não vem da capacidade corporal, mas sim de uma vontade indomável." - Mahatma Gandhi'],
        music: ['Nome da Música 1 - Artista', 'Nome da Música 2 - Artista'],
        whys: [
          { question: 'Por que quero mudar?', answer: '' },
          { question: 'Por que acordo cedo?', answer: '' },
          { question: 'Por que cuido de mim?', answer: '' },
          { question: 'Qual meu propósito maior?', answer: '' },
        ],
        altarContent: '',
      });
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('inspiracao_data', JSON.stringify(data));
  }, [data]);

  const handleSaveItem = (category: 'quotes' | 'music') => (oldItem: string, newItem: string) => {
    setData(prevData => ({
      ...prevData,
      [category]: prevData[category].map(item => item === oldItem ? newItem : item)
    }));
    if (oldItem === '') setNewItemType(null); // Close add input if it was a new item
  };

  const handleDeleteItem = (category: 'quotes' | 'music') => (itemToDelete: string) => {
    setData(prevData => ({
      ...prevData,
      [category]: prevData[category].filter(item => item !== itemToDelete)
    }));
     if (itemToDelete === '') setNewItemType(null); // Close add input if it was a new item being deleted before save
  };

  const handleAddItem = (category: 'quotes' | 'music') => {
    if (!data[category].includes('')) { // Prevent adding multiple empty inputs
        setData(prevData => ({
            ...prevData,
            [category]: [...prevData[category], '']
        }));
        setNewItemType(category);
    }
  };

  const handleSaveWhy = (question: string, newAnswer: string) => {
    setData(prevData => ({
      ...prevData,
      whys: prevData.whys.map(why => why.question === question ? { ...why, answer: newAnswer } : why)
    }));
  };

  const handleSaveAltar = (content: string) => {
    setData(prevData => ({ ...prevData, altarContent: content }));
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6 text-purple-700">Inspiração & Reconexão</h1>

      <div className="grid md:grid-cols-2 gap-6">

        {/* Imagens e Frases Inspiradoras */}
        <Card className="bg-rose-50">
          <h2 className="text-xl font-semibold mb-4 text-rose-700 flex items-center">
            <ImageIcon className="mr-2" size={24} /> Imagens que Inspiram
          </h2>
          <div className="grid grid-cols-2 gap-2 mb-4">
            {/* Placeholder for images - Image upload/management is complex for this scope */}
            <div className="w-full h-32 bg-gray-200 rounded flex items-center justify-center text-gray-500 text-sm">Imagem 1</div>
            <div className="w-full h-32 bg-gray-200 rounded flex items-center justify-center text-gray-500 text-sm">Imagem 2</div>
            <div className="w-full h-32 bg-gray-200 rounded flex items-center justify-center text-gray-500 text-sm">Imagem 3</div>
            <div className="w-full h-32 bg-gray-200 rounded flex items-center justify-center text-gray-500 text-sm">Imagem 4</div>
          </div>
          <h2 className="text-xl font-semibold mb-2 text-rose-700 flex items-center justify-between">
            <div className="flex items-center"><Quote className="mr-2" size={24} /> Frases de Poder</div>
            <Button size="sm" variant="secondary" onClick={() => handleAddItem('quotes')} className="text-xs"><Plus size={14} className="mr-1"/> Add</Button>
          </h2>
          <ul className="mb-3 space-y-1">
            {data.quotes.map((quote, index) => (
              <EditableListItem
                key={index} // Using index is okay here if list order doesn't change drastically
                item={quote}
                onSave={handleSaveItem('quotes')}
                onDelete={handleDeleteItem('quotes')}
                placeholder="Nova frase..."
              />
            ))}
          </ul>
        </Card>

        {/* Músicas e Porquês */}
        <Card className="bg-sky-50">
          <h2 className="text-xl font-semibold mb-2 text-sky-700 flex items-center justify-between">
            <div className="flex items-center"><Music className="mr-2" size={24} /> Músicas para Reconectar</div>
             <Button size="sm" variant="secondary" onClick={() => handleAddItem('music')} className="text-xs"><Plus size={14} className="mr-1"/> Add</Button>
          </h2>
          <ul className="mb-6 space-y-1">
             {data.music.map((musicItem, index) => (
              <EditableListItem
                key={index}
                item={musicItem}
                onSave={handleSaveItem('music')}
                onDelete={handleDeleteItem('music')}
                placeholder="Nova música/link..."
              />
            ))}
          </ul>

          <h2 className="text-xl font-semibold mb-4 text-sky-700 flex items-center">
            <Sparkles className="mr-2" size={24} /> Meus Porquês
          </h2>
          <div className="space-y-2">
            {data.whys.map((why, index) => (
              <EditableWhyItem key={index} why={why} onSave={handleSaveWhy} />
            ))}
          </div>
        </Card>

        {/* Altar Digital */}
        <Card className="md:col-span-2 bg-purple-50">
          <h2 className="text-xl font-semibold mb-4 text-purple-700 flex items-center">
            <Heart className="mr-2" size={24} /> Meu Altar Digital
          </h2>
          <p className="text-gray-600 mb-4 italic text-sm">
            Um espaço simbólico de refúgio, gratidão e lembrança da sua essência. Adicione textos, links ou símbolos que te conectam com sua força interior.
          </p>
          <textarea
            className="w-full h-40 p-3 border border-purple-200 rounded-md focus:ring-1 focus:ring-purple-400 focus:border-transparent resize-none bg-white text-sm"
            placeholder="Adicione aqui seus símbolos, textos, links..."
            value={data.altarContent}
            onChange={(e) => handleSaveAltar(e.target.value)} // Save on change for simplicity
          ></textarea>
        </Card>

      </div>
    </div>
  );
};

export default InspiracaoPage;

